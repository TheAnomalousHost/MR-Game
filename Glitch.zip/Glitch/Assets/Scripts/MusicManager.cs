﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicManager : MonoBehaviour {

	//Music by Eric Matyas,	www.soundimage.org

	public AudioClip[] musicTrack;
	private AudioSource audioSource;

	void Awake(){
		DontDestroyOnLoad (gameObject);
	}

	void Start(){
		audioSource = gameObject.GetComponent<AudioSource> ();
		audioSource.clip = musicTrack [0];
		audioSource.Play ();
	}
}
