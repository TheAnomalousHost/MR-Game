﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BlankHex : MonoBehaviour {

	/*
	 * Colors:
	 * black 0,0,0
	 * blue 0,0,1
	 * clear 0,0,0,0
	 * cyan 0,1,1
	 * gray 0.5,0.5,0.5
	 * green 0,1,0
	 * magenta 1,0,1
	 * red 1,0,0
	 * white 1,1,1
	 * yellow 1,0.92,0.016
	 * 
	 * 
	 * 
	 * Hex edge IDs:
	 * 
	 *       ___4___
	 *      /       \
	 *    3/         \5
	 *    /           \
	 *    \           /
	 *    2\         /6
	 *      \_______/
	 *          1
	 * 
	 * 
	 * For easier testing, 6 cubes will be created upon tile placement on hex.  They will be positioned along the 6 edges.
	 * Once placed, they will be blue colored if they are on an edge that links back to borderlands, red colored if they are not.
	 * Might keep this system in place for ease of learning for new players.
	 *
	*/

	public GameObject visualEdge1Aid; Vector3 visualEdge1AidPos = new Vector3 (-0.02f, -2.1f, -0.02f); 
	public GameObject visualEdge2Aid; Vector3 visualEdge2AidPos = new Vector3 (-1.75f, -1.16f, -0.02f); 
	public GameObject visualEdge3Aid; Vector3 visualEdge3AidPos = new Vector3 (-1.75f, 1.16f, -0.02f); 
	public GameObject visualEdge4Aid; Vector3 visualEdge4AidPos = new Vector3 (-0.02f, 2.1f, -0.02f); 
	public GameObject visualEdge5Aid; Vector3 visualEdge5AidPos = new Vector3 (1.75f, 1.16f, -0.02f); 
	public GameObject visualEdge6Aid; Vector3 visualEdge6AidPos = new Vector3 (1.75f, -1.16f, -0.02f);
	private Vector3 visualEdgeAidScale = new Vector3 (1f, 0.1f, 0.1f);

	//the below materials are for the visualEdgeAides
	Material redMaterial;
	Material blueMaterial;
	Material greenMaterial;


	bool selected;//hex position is selected for placement
	bool placed;//hex position filled, can no longer be selected

	static GameObject gameManager;
	public static int numberOfHexes = 1;

	private const string startHexName = "Hex 0";

	const float shiftX = 3.75f;
	const float shiftYSmall = 2.16f;
	const float shiftYBig = 4.32f;

	public GameObject adjHex1;//neighbor1;
	public GameObject adjHex2;//neighbor2;
	public GameObject adjHex3;//neighbor3;
	public GameObject adjHex4;//neighbor4;
	public GameObject adjHex5;//neighbor5;
	public GameObject adjHex6;//neighbor6;

	public bool roadAt1;//true if there is a road leading out of edge 1
	public bool roadAt2;
	public bool roadAt3;
	public bool roadAt4;
	public bool roadAt5;
	public bool roadAt6;

	public bool e1_Borderland;//true if edge 1 road links to the Borderland tile
	public bool e2_Borderland;
	public bool e3_Borderland;
	public bool e4_Borderland;
	public bool e5_Borderland;
	public bool e6_Borderland;

	public bool sixClearingTile;//if tile has 6 clearings, this must be true;

	public bool edge1_edge2;//true if there is a road on this hex that leads from edge 1 to edge 2, else false
	public bool edge1_edge3;
	public bool edge1_edge4;
	public bool edge1_edge5;
	public bool edge1_edge6;

	public bool edge2_edge1;
	public bool edge2_edge3;
	public bool edge2_edge4;
	public bool edge2_edge5;
	public bool edge2_edge6;

	public bool edge3_edge1;
	public bool edge3_edge2;
	public bool edge3_edge4;
	public bool edge3_edge5;
	public bool edge3_edge6;

	public bool edge4_edge1;
	public bool edge4_edge2;
	public bool edge4_edge3;
	public bool edge4_edge4;
	public bool edge4_edge5;
	public bool edge4_edge6;

	public bool edge5_edge1;
	public bool edge5_edge2;
	public bool edge5_edge3;
	public bool edge5_edge4;
	public bool edge5_edge6;

	public bool edge6_edge1;
	public bool edge6_edge2;
	public bool edge6_edge3;
	public bool edge6_edge4;
	public bool edge6_edge5;

	private Color redColor = new Color(1, 0, 0);//could also do = Color.red;



	GameObject uiBackground;
	float uiBorder;//set to the width of uiBackground to determine when mouse should not interact with non-ui objects


	public struct HexID{
		int posA, posB;

		public HexID(int a, int b){
			posA = a;
			posB = b;
		}

		public int GetPosA(){
			return posA;
		}

		public int GetPosB(){
			return posB;
		}
	}

	HexID hexID;
	public string ID;


	void Start () {
		gameManager = GameObject.FindGameObjectWithTag ("GameController");
		
		selected = false;
		placed = false;

		//start of game hex slot
		//there should only be 1 blank hex at start of realm creation, unless using some variant like SuperRealm (much further down the line)
		if (gameObject.name == startHexName) {
			hexID = new HexID (0, 0);
		}
		ID = hexID.GetPosA ().ToString () + ", " + hexID.GetPosB ().ToString ();

		uiBackground = GameObject.FindGameObjectWithTag ("Canvas").transform.FindChild ("UI Background").gameObject;
		uiBorder = uiBackground.GetComponent<RectTransform> ().rect.width;

		blueMaterial = Resources.Load ("MaterialBlue", typeof(Material)) as Material;
		greenMaterial = Resources.Load ("MaterialGreen", typeof(Material)) as Material;
		redMaterial = Resources.Load ("MaterialRed", typeof(Material)) as Material;
	}


	//player is preparing to select hex position for placement
	void OnMouseEnter(){
		if (!placed && gameManager.GetComponent<GameManager>().uiHexSelected && Input.mousePosition.x > uiBorder) {
			gameObject.GetComponent<SpriteRenderer> ().color = new Color (0, 1, 0);//green
			selected = true;
		}
	}


	//player decides not to place hex here, for now
	void OnMouseExit(){
		if (!placed) {
			gameObject.GetComponent<SpriteRenderer> ().color = Color.grey;//grey
			selected = false;
		}
	}
		

	public GameObject GetNeighbor1(){return adjHex1;}
	public void SetNeighbor1(GameObject n){	adjHex1 = n;}
	public GameObject GetNeighbor2(){return adjHex2;}
	public void SetNeighbor2(GameObject n){adjHex2 = n;}
	public GameObject GetNeighbor3(){return adjHex3;}
	public void SetNeighbor3(GameObject n){adjHex3 = n;}
	public GameObject GetNeighbor4(){return adjHex4;}
	public void SetNeighbor4(GameObject n){adjHex4 = n;}
	public GameObject GetNeighbor5(){return adjHex5;}
	public void SetNeighbor5(GameObject n){adjHex5 = n;}
	public GameObject GetNeighbor6(){return adjHex6;}
	public void SetNeighbor6(GameObject n){adjHex6 = n;}


	public bool HexIsPlaced(){
		return placed;
	}

	public bool GetEdge1_Borderland(){return e1_Borderland;}
	public bool GetEdge2_Borderland(){return e2_Borderland;}
	public bool GetEdge3_Borderland(){return e3_Borderland;}
	public bool GetEdge4_Borderland(){return e4_Borderland;}
	public bool GetEdge5_Borderland(){return e5_Borderland;}
	public bool GetEdge6_Borderland(){return e6_Borderland;}


	//player will place hex tile in this selected spot, then automatically create new hex slots around it, if necessary
	void OnMouseUp(){
		//Debug.Log ("mousePosition.x = " + Input.mousePosition.x);
		//Debug.Log ("uiBorder x value = " + uiBorder);
		if (selected && !placed && gameManager.GetComponent<GameManager>().uiHexSelected && Input.mousePosition.x > uiBorder) {

			//There should only be 1 blank hex at the start of map creation.  From there that will create 6 new blank hexes.

			//if placed next to < 2 adjacent tiles and there is more than just the starting hex slots, it's illegal
			if (!IsTilePlacementLegal () && numberOfHexes > 7) {
				gameObject.GetComponent<SpriteRenderer> ().color = redColor;
				return;
			}

			//find the tile that is to be placed
			foreach (GameObject a in GameObject.FindGameObjectWithTag("Canvas").GetComponent<UI_TileDisplay>().GetDisplayedUITiles()) {
				if (a.GetComponent<Tile_UI> ().selected) {//found tile that is to be placed

					//first tile placed must be the Borderland
					if (gameObject.name == startHexName && a.name != "Borderland") {
						return;
					}

					//if not the Borderland (Hex 0), make sure roads align with edges of neighbor(s) hex tiles
					if (gameObject.name != startHexName) {
						//assign roads appropriately
						roadAt1 = a.GetComponent<Tile_UI> ().roadAt1;
						roadAt2 = a.GetComponent<Tile_UI> ().roadAt2;
						roadAt3 = a.GetComponent<Tile_UI> ().roadAt3;
						roadAt4 = a.GetComponent<Tile_UI> ().roadAt4;
						roadAt5 = a.GetComponent<Tile_UI> ().roadAt5;
						roadAt6 = a.GetComponent<Tile_UI> ().roadAt6;

						edge1_edge2 = a.GetComponent<Tile_UI> ().edge1_edge2;
						edge1_edge3 = a.GetComponent<Tile_UI> ().edge1_edge3;
						edge1_edge4 = a.GetComponent<Tile_UI> ().edge1_edge4;
						edge1_edge5 = a.GetComponent<Tile_UI> ().edge1_edge5;
						edge1_edge6 = a.GetComponent<Tile_UI> ().edge1_edge6;

						edge2_edge1 = a.GetComponent<Tile_UI> ().edge2_edge1;
						edge2_edge3 = a.GetComponent<Tile_UI> ().edge2_edge3;
						edge2_edge4 = a.GetComponent<Tile_UI> ().edge2_edge4;
						edge2_edge5 = a.GetComponent<Tile_UI> ().edge2_edge5;
						edge2_edge6 = a.GetComponent<Tile_UI> ().edge2_edge6;

						edge3_edge1 = a.GetComponent<Tile_UI> ().edge3_edge1;
						edge3_edge2 = a.GetComponent<Tile_UI> ().edge3_edge2;
						edge3_edge4 = a.GetComponent<Tile_UI> ().edge3_edge4;
						edge3_edge5 = a.GetComponent<Tile_UI> ().edge3_edge5;
						edge3_edge6 = a.GetComponent<Tile_UI> ().edge3_edge6;

						edge4_edge1 = a.GetComponent<Tile_UI> ().edge4_edge1;
						edge4_edge2 = a.GetComponent<Tile_UI> ().edge4_edge2;
						edge4_edge3 = a.GetComponent<Tile_UI> ().edge4_edge3;
						edge4_edge5 = a.GetComponent<Tile_UI> ().edge4_edge5;
						edge4_edge6 = a.GetComponent<Tile_UI> ().edge4_edge6;

						edge5_edge1 = a.GetComponent<Tile_UI> ().edge5_edge1;
						edge5_edge2 = a.GetComponent<Tile_UI> ().edge5_edge2;
						edge5_edge3 = a.GetComponent<Tile_UI> ().edge5_edge3;
						edge5_edge4 = a.GetComponent<Tile_UI> ().edge5_edge4;
						edge5_edge6 = a.GetComponent<Tile_UI> ().edge5_edge6;

						edge6_edge1 = a.GetComponent<Tile_UI> ().edge6_edge1;
						edge6_edge2 = a.GetComponent<Tile_UI> ().edge6_edge2;
						edge6_edge3 = a.GetComponent<Tile_UI> ().edge6_edge3;
						edge6_edge4 = a.GetComponent<Tile_UI> ().edge6_edge4;
						edge6_edge5 = a.GetComponent<Tile_UI> ().edge6_edge5;

						//mark if it's a 6-clearing tile
						sixClearingTile = a.GetComponent<Tile_UI> ().sixClearingTile;

						//now check the roads of the neighbor hex tiles, and update this tile's Borderland paths
						if (sixClearingTile == false) {
							if (TravelTilePlacementCheck () == false) {
								return;//check failed, placement is illegal
							}
						} else {
							if (SixClearingTilePlacementCheck () == false) {
								return;//check failed, placement is illegal
							}
						}

					} else {//it's the Borderlands, all edges have roads
						roadAt1 = true;
						roadAt2 = true;
						roadAt3 = true;
						roadAt4 = true;
						roadAt5 = true;
						roadAt6 = true;
						e1_Borderland = true;
						e2_Borderland = true;
						e3_Borderland = true;
						e4_Borderland = true;
						e5_Borderland = true;
						e6_Borderland = true;
					}
					//Debug.Log ("Placement is legal.");

					//set tile sprite
					gameObject.GetComponent<SpriteRenderer> ().sprite = a.GetComponent<Image> ().sprite;
					gameObject.name = a.name;

					//set temporary edge markers for making visual notification of which roads/edges lead back to the Borderland
					visualEdge1Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge1Aid.name = "Edge 1 Aid";
					visualEdge1Aid.transform.SetParent (gameObject.transform);
					visualEdge1Aid.transform.localScale = visualEdgeAidScale;
					visualEdge1Aid.transform.localPosition = visualEdge1AidPos;
					visualEdge1Aid.transform.Rotate (-90, 0, 0);
					if (e1_Borderland) {
						visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt1) {
						visualEdge1Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge1Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					visualEdge2Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge2Aid.name = "Edge 2 Aid";
					visualEdge2Aid.transform.SetParent (gameObject.transform);
					visualEdge2Aid.transform.localScale = visualEdgeAidScale;
					visualEdge2Aid.transform.localPosition = visualEdge2AidPos;
					visualEdge2Aid.transform.Rotate (-150, -90, 90);
					if (e2_Borderland) {
						visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt2) {
						visualEdge2Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge2Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					visualEdge3Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge3Aid.name = "Edge 3 Aid";
					visualEdge3Aid.transform.SetParent (gameObject.transform);
					visualEdge3Aid.transform.localScale = visualEdgeAidScale;
					visualEdge3Aid.transform.localPosition = visualEdge3AidPos;
					visualEdge3Aid.transform.Rotate (-30, -90, 90);
					if (e3_Borderland) {
						visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt3) {
						visualEdge3Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge3Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					visualEdge4Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge4Aid.name = "Edge 4 Aid";
					visualEdge4Aid.transform.SetParent (gameObject.transform);
					visualEdge4Aid.transform.localScale = visualEdgeAidScale;
					visualEdge4Aid.transform.localPosition = visualEdge4AidPos;
					visualEdge4Aid.transform.Rotate (-90, 0, 0);
					if (e4_Borderland) {
						visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt4) {
						visualEdge4Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge4Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					visualEdge5Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge5Aid.name = "Edge 5 Aid";
					visualEdge5Aid.transform.SetParent (gameObject.transform);
					visualEdge5Aid.transform.localScale = visualEdgeAidScale;
					visualEdge5Aid.transform.localPosition = visualEdge5AidPos;
					visualEdge5Aid.transform.Rotate (-150, -90, 90);
					if (e5_Borderland) {
						visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt5) {
						visualEdge5Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge5Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					visualEdge6Aid = GameObject.CreatePrimitive (PrimitiveType.Cube);
					visualEdge6Aid.name = "Edge 6 Aid";
					visualEdge6Aid.transform.SetParent (gameObject.transform);
					visualEdge6Aid.transform.localScale = visualEdgeAidScale;
					visualEdge6Aid.transform.localPosition = visualEdge6AidPos;
					visualEdge6Aid.transform.Rotate (-30, -90, 90);
					if (e6_Borderland) {
						visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
					} else if (roadAt6) {
						visualEdge6Aid.GetComponent<MeshRenderer> ().material = redMaterial;
					} else {
						visualEdge6Aid.GetComponent<MeshRenderer> ().material = blueMaterial;
					}

					//make sure the visualedge1aids are not children of this gameobject during rotation; scaling might be ok, but won't chance it for now
					visualEdge1Aid.transform.SetParent (gameObject.transform.parent, true);
					visualEdge2Aid.transform.SetParent (gameObject.transform.parent, true);
					visualEdge3Aid.transform.SetParent (gameObject.transform.parent, true);
					visualEdge4Aid.transform.SetParent (gameObject.transform.parent, true);
					visualEdge5Aid.transform.SetParent (gameObject.transform.parent, true);
					visualEdge6Aid.transform.SetParent (gameObject.transform.parent, true);

					//rotate tile to correct orientation if necessary
					gameObject.transform.Rotate(new Vector3(0, 0, -60 * (a.GetComponent<Tile_UI>().GetRotation() - 1)));

					//because scaling of sprite itself is off, rescale gameobject to fit the grid appropriately
					//then set visual edge aids to be children of this gameobject, done here to prevent awkwards position due to rotation and scaling changes
					gameObject.transform.localScale = new Vector3 (1, 1, 1);

					visualEdge1Aid.transform.SetParent (gameObject.transform, true);
					visualEdge2Aid.transform.SetParent (gameObject.transform, true);
					visualEdge3Aid.transform.SetParent (gameObject.transform, true);
					visualEdge4Aid.transform.SetParent (gameObject.transform, true);
					visualEdge5Aid.transform.SetParent (gameObject.transform, true);
					visualEdge6Aid.transform.SetParent (gameObject.transform, true);

					//update UI Tile display
					gameManager.GetComponent<GameManager> ().uiHexSelected = false;//deselect
					GameObject.FindGameObjectWithTag ("Canvas").GetComponent<UI_TileDisplay> ().UpdateDisplayedUITiles(a);
					break;
				}
			}

			//now update neighbors in regards to paths leading back to Borderland, if necessary
			if (adjHex1 != null) {
				if (e1_Borderland && adjHex1.GetComponent<BlankHex> ().HexIsPlaced () && adjHex1.GetComponent<BlankHex> ().roadAt4 && adjHex1.GetComponent<BlankHex> ().e4_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 4 of " + adjHex1.name);
					UpdatePathsToBorderland (adjHex1, 4);
				}
			}
			if (adjHex2 != null) {
				Debug.Log ("Checking " + adjHex2.name);
				if (e2_Borderland && adjHex2.GetComponent<BlankHex> ().HexIsPlaced () && adjHex2.GetComponent<BlankHex> ().roadAt5 && adjHex2.GetComponent<BlankHex> ().e5_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 5 of " + adjHex2.name);
					UpdatePathsToBorderland (adjHex2, 5);
				}
			}
			if (adjHex3 != null) {
				if (e3_Borderland && adjHex3.GetComponent<BlankHex> ().HexIsPlaced () && adjHex3.GetComponent<BlankHex> ().roadAt6 && adjHex3.GetComponent<BlankHex> ().e6_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 6 of " + adjHex3.name);
					UpdatePathsToBorderland (adjHex3, 6);
				}
			}
			if (adjHex4 != null) {
				if (e4_Borderland && adjHex4.GetComponent<BlankHex> ().HexIsPlaced () && adjHex4.GetComponent<BlankHex> ().roadAt1 && adjHex4.GetComponent<BlankHex> ().e1_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 1 of " + adjHex4.name);
					UpdatePathsToBorderland (adjHex4, 1);
				}
			}
			if (adjHex5 != null) {
				if (e5_Borderland && adjHex5.GetComponent<BlankHex> ().HexIsPlaced () && adjHex5.GetComponent<BlankHex> ().roadAt2 && adjHex5.GetComponent<BlankHex> ().e2_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 2 of " + adjHex5.name);
					UpdatePathsToBorderland (adjHex5, 2);
				}
			}
			if (adjHex6 != null) {
				if (e6_Borderland && adjHex6.GetComponent<BlankHex> ().HexIsPlaced () && adjHex6.GetComponent<BlankHex> ().roadAt3 && adjHex6.GetComponent<BlankHex> ().e3_Borderland == false) {
					Debug.Log ("Updating Borderland road confirmation on edge 3 of " + adjHex6.name);
					UpdatePathsToBorderland (adjHex6, 3);
				}
			}

			//The color of the sprite remains green due to OnMouseEnter function.  Change it back to grey here.
			gameObject.GetComponent<SpriteRenderer>().color = Color.grey;

			placed = true;//aka filled

			//tracks which new hex slots were placed as a result of the new hex tile (this gameobject)
			GameObject newAdjHex1 = null;
			GameObject newAdjHex2 = null;
			GameObject newAdjHex3 = null;
			GameObject newAdjHex4 = null;
			GameObject newAdjHex5 = null;
			GameObject newAdjHex6 = null;

			Vector3 newHexSlotPosition = gameObject.transform.position;//pre-position for new hex slot to be placed; will be altered with if-statements below

			//after tile is placed in slot, create 0-3 new hex slots adjacent to it, and have them all connect to this hex tile
			if (adjHex1 == null) {//checking for hex slots that were adjecent to this hex tile during the time it was a hex slot
				newHexSlotPosition.y -= shiftYBig;

				//state that this hex tile is adjacent to new hex slot which will be connected by the '1' side (south hex) of this hex tile
				adjHex1 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);//added in blank prefab hex slot
				adjHex1.transform.position = newHexSlotPosition;
				adjHex1.GetComponent<BlankHex> ().adjHex4 = gameObject;
				adjHex1.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA (), hexID.GetPosB () + 1);
				adjHex1.GetComponent<BlankHex> ().ID = hexID.GetPosA ().ToString () + ", " + (hexID.GetPosB () + 1).ToString ();//TODO: was there a reason to do both this and the previous line?
				adjHex1.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex1.name = "Hex " + numberOfHexes;
				numberOfHexes++;

				newAdjHex1 = adjHex1;

				newHexSlotPosition.y = gameObject.transform.position.y;//reset position
			}
			if (adjHex2 == null) {
				newHexSlotPosition.x -= shiftX;
				newHexSlotPosition.y -= shiftYSmall;

				adjHex2 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);
				adjHex2.transform.position = newHexSlotPosition;
				adjHex2.GetComponent<BlankHex> ().adjHex5 = gameObject;
				adjHex2.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA () - 1, hexID.GetPosB () + 1);
				adjHex2.GetComponent<BlankHex> ().ID = (hexID.GetPosA () - 1).ToString () + ", " + (hexID.GetPosB () + 1).ToString ();
				adjHex2.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex2.name = "Hex " + numberOfHexes;
				numberOfHexes++;

				newAdjHex2 = adjHex2;

				newHexSlotPosition.x = gameObject.transform.position.x;
				newHexSlotPosition.y = gameObject.transform.position.y;
			}
			if (adjHex3 == null) {
				newHexSlotPosition.x -= shiftX;
				newHexSlotPosition.y += shiftYSmall;

				adjHex3 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);
				adjHex3.transform.position = newHexSlotPosition;
				adjHex3.GetComponent<BlankHex> ().adjHex6 = gameObject;
				adjHex3.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA () - 1, hexID.GetPosB ());
				adjHex3.GetComponent<BlankHex> ().ID = (hexID.GetPosA () - 1).ToString () + ", " + (hexID.GetPosB ()).ToString ();
				adjHex3.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex3.name = "Hex " + numberOfHexes;				
				numberOfHexes++;

				newAdjHex3 = adjHex3;

				newHexSlotPosition.x = gameObject.transform.position.x;
				newHexSlotPosition.y = gameObject.transform.position.y;
			}
			if (adjHex4 == null) {
				newHexSlotPosition.y += shiftYBig;

				adjHex4 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);
				adjHex4.transform.position = newHexSlotPosition;
				adjHex4.GetComponent<BlankHex> ().adjHex1 = gameObject;
				adjHex4.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA (), hexID.GetPosB () - 1);
				adjHex4.GetComponent<BlankHex> ().ID = (hexID.GetPosA ()).ToString () + ", " + (hexID.GetPosB () - 1).ToString ();
				adjHex4.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex4.name = "Hex " + numberOfHexes;
				numberOfHexes++;

				newAdjHex4 = adjHex4;

				newHexSlotPosition.y = gameObject.transform.position.y;
			}
			if (adjHex5 == null) {
				newHexSlotPosition.x += shiftX;
				newHexSlotPosition.y += shiftYSmall;

				adjHex5 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);
				adjHex5.transform.position = newHexSlotPosition;
				adjHex5.GetComponent<BlankHex> ().adjHex2 = gameObject;
				adjHex5.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA () + 1, hexID.GetPosB () - 1);
				adjHex5.GetComponent<BlankHex> ().ID = (hexID.GetPosA () + 1).ToString () + ", " + (hexID.GetPosB () - 1).ToString ();
				adjHex5.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex5.name = "Hex " + numberOfHexes;
				numberOfHexes++;

				newAdjHex5 = adjHex5;

				newHexSlotPosition.x = gameObject.transform.position.x;
				newHexSlotPosition.y = gameObject.transform.position.y;
			}
			if (adjHex6 == null) {
				newHexSlotPosition.x += shiftX;
				newHexSlotPosition.y -= shiftYSmall;

				adjHex6 = Instantiate (gameManager.GetComponent<GameManager> ().GetHexSlot (), GameObject.FindGameObjectWithTag ("Tiles").transform);
				adjHex6.transform.position = newHexSlotPosition;
				adjHex6.GetComponent<BlankHex> ().adjHex3 = gameObject;
				adjHex6.GetComponent<BlankHex> ().hexID = new HexID (hexID.GetPosA () + 1, hexID.GetPosB ());
				adjHex6.GetComponent<BlankHex> ().ID = (hexID.GetPosA () + 1).ToString () + ", " + (hexID.GetPosB ()).ToString ();
				adjHex6.GetComponent<SpriteRenderer>().color = Color.grey;

				adjHex6.name = "Hex " + numberOfHexes;
				numberOfHexes++;

				newAdjHex6 = adjHex6;

				newHexSlotPosition.x = gameObject.transform.position.x;
				newHexSlotPosition.y = gameObject.transform.position.y;
			}

			//after new hex slots are placed and linked to hex tile, connect new hex slots to the other adjacent hexes that are also adjacent to this hex tile
			if (newAdjHex1 != null) {
				adjHex1.GetComponent<BlankHex> ().adjHex3 = adjHex2;
				adjHex2.GetComponent<BlankHex> ().adjHex6 = adjHex1;

				adjHex1.GetComponent<BlankHex> ().adjHex5 = adjHex6;
				adjHex6.GetComponent<BlankHex> ().adjHex2 = adjHex1;

				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex1);
			}
			if (newAdjHex2 != null) {
				adjHex2.GetComponent<BlankHex> ().adjHex4 = adjHex3;
				adjHex3.GetComponent<BlankHex> ().adjHex1 = adjHex2;

				adjHex2.GetComponent<BlankHex> ().adjHex6 = adjHex1;
				adjHex1.GetComponent<BlankHex> ().adjHex3 = adjHex2;

				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex2);
			}
			if (newAdjHex3 != null) {
				adjHex3.GetComponent<BlankHex> ().adjHex5 = adjHex4;
				adjHex4.GetComponent<BlankHex> ().adjHex2 = adjHex3;

				adjHex3.GetComponent<BlankHex> ().adjHex1 = adjHex2;
				adjHex2.GetComponent<BlankHex> ().adjHex4 = adjHex3;


				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex3);
			}
			if (newAdjHex4 != null) {
				adjHex4.GetComponent<BlankHex> ().adjHex6 = adjHex5;
				adjHex5.GetComponent<BlankHex> ().adjHex3 = adjHex4;

				adjHex4.GetComponent<BlankHex> ().adjHex2 = adjHex3;
				adjHex3.GetComponent<BlankHex> ().adjHex5 = adjHex4;

				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex4);
			}
			if (newAdjHex5 != null) {
				adjHex5.GetComponent<BlankHex> ().adjHex1 = adjHex6;
				adjHex6.GetComponent<BlankHex> ().adjHex4 = adjHex5;

				adjHex5.GetComponent<BlankHex> ().adjHex3 = adjHex4;
				adjHex4.GetComponent<BlankHex> ().adjHex6 = adjHex5;

				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex5);
			}
			if (newAdjHex6 != null) {
				adjHex6.GetComponent<BlankHex> ().adjHex2 = adjHex1;
				adjHex1.GetComponent<BlankHex> ().adjHex5 = adjHex6;

				adjHex6.GetComponent<BlankHex> ().adjHex4 = adjHex5;
				adjHex5.GetComponent<BlankHex> ().adjHex1 = adjHex6;

				gameManager.GetComponent<GameManager> ().AddToRealmMap (adjHex6);
			}

			//only thing left to check is if 2 adjacent hex slots are not connected, and connect them, using hexID for reference.
			//probably best to use GameManager to store all hexes, and reference their ID's
			
			//check neighbor hex slots for potential unlinked adjacent hex slots
			if(!GetNeighbor1().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor1 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor1());
			}
			if(!GetNeighbor2().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor2 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor2());
			}
			if(!GetNeighbor3().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor3 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor3());
			}
			if(!GetNeighbor4().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor4 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor4());
			}
			if(!GetNeighbor5().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor5 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor5());
			}
			if(!GetNeighbor6().GetComponent<BlankHex>().HexIsPlaced()){
				//Debug.Log ("Checking neighbor6 for non-linked linkable neighbors.");
				CheckForAdjacentSlots (GetNeighbor6());
			}
		}

		//check to see if the last tile has been placed
		//EndOfMapBuilding();
	}



	void CheckForAdjacentSlots(GameObject hexSlotA){
	if (hexSlotA.GetComponent<BlankHex> ().GetNeighbor1() == null || hexSlotA.GetComponent<BlankHex> ().GetNeighbor2() == null || hexSlotA.GetComponent<BlankHex> ().GetNeighbor3() == null ||
		hexSlotA.GetComponent<BlankHex> ().GetNeighbor4() == null || hexSlotA.GetComponent<BlankHex> ().GetNeighbor5() == null || hexSlotA.GetComponent<BlankHex> ().GetNeighbor6() == null) {
			List<GameObject> slotMap = gameManager.GetComponent<GameManager> ().GetRealmMap ();
			foreach (GameObject a in slotMap) {
			if (!a.GetComponent<BlankHex> ().HexIsPlaced ()) {
					if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA()) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB() + 1) &&
					a.GetComponent<BlankHex>().GetNeighbor4() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex1 = a;
						a.GetComponent<BlankHex> ().adjHex4 = hexSlotA;
					}
				if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA() - 1) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB() + 1) &&
					a.GetComponent<BlankHex>().GetNeighbor5() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex2 = a;
						a.GetComponent<BlankHex> ().adjHex5 = hexSlotA;
					}
				if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA() - 1) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB()) &&
					a.GetComponent<BlankHex>().GetNeighbor6() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex3 = a;
						a.GetComponent<BlankHex> ().adjHex6 = hexSlotA;
					}
					if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA()) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB() -1) &&
					a.GetComponent<BlankHex>().GetNeighbor1() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex4 = a;
						a.GetComponent<BlankHex> ().adjHex1 = hexSlotA;
					}
				if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA() + 1) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB() - 1) &&
					a.GetComponent<BlankHex>().GetNeighbor2() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex5 = a;
						a.GetComponent<BlankHex> ().adjHex2 = hexSlotA;
					}
				if ((a.GetComponent<BlankHex> ().hexID.GetPosA () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosA() + 1) &&
					(a.GetComponent<BlankHex> ().hexID.GetPosB () == hexSlotA.GetComponent<BlankHex>().hexID.GetPosB()) &&
					a.GetComponent<BlankHex>().GetNeighbor3() == null) {
						hexSlotA.GetComponent<BlankHex> ().adjHex6 = a;
						a.GetComponent<BlankHex> ().adjHex3 = hexSlotA;
					}
				}
			}
		}
	}


	//check if new hex tile placement is legal based on # of neighbors (must be at least 2 neighbors)
	bool IsTilePlacementLegal(){
		int tileNeighbors = 0;
		if (GetNeighbor1 () != null && GetNeighbor1 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (GetNeighbor2 () != null && GetNeighbor2 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (GetNeighbor3 () != null && GetNeighbor3 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (GetNeighbor4 () != null && GetNeighbor4 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (GetNeighbor5 () != null && GetNeighbor5 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (GetNeighbor6 () != null && GetNeighbor6 ().GetComponent<BlankHex> ().HexIsPlaced ()) { 
			tileNeighbors++;
		}
		if (tileNeighbors >= 2) {
			return true;
		} else {
			return false;
		}
	}


	//check if non-6-clearing tile placement is legal based on roads of connected tiles leading back to the Borderland
	private bool TravelTilePlacementCheck(){
		bool oneNeighborAdjacentToBorderland = false;
		if (adjHex1 != null) {
			if (adjHex1.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex1.GetComponent<BlankHex> ().roadAt4 && roadAt1) || (!adjHex1.GetComponent<BlankHex> ().roadAt4 && !roadAt1)) {
					if (adjHex1.GetComponent<BlankHex> ().GetEdge4_Borderland ()) {//check if adjacent hex connects to Borderland from this hex's connected edge
						oneNeighborAdjacentToBorderland = true;
						e1_Borderland = true;
						if (edge1_edge2) {
							e2_Borderland = true;
						}
						if (edge1_edge3) {
							e3_Borderland = true;
						}
						if (edge1_edge4) {
							e4_Borderland = true;
						}
						if (edge1_edge5) {
							e5_Borderland = true;
						}
						if (edge1_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 1.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex2 != null) {
			if (adjHex2.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex2.GetComponent<BlankHex> ().roadAt5 && roadAt2) || (!adjHex2.GetComponent<BlankHex> ().roadAt5 && !roadAt2)) {
					if (adjHex2.GetComponent<BlankHex> ().GetEdge5_Borderland ()) {
						oneNeighborAdjacentToBorderland = true;
						e2_Borderland = true;
						if (edge2_edge1) {
							e1_Borderland = true;
						}
						if (edge2_edge3) {
							e3_Borderland = true;
						}
						if (edge2_edge4) {
							e4_Borderland = true;
						}
						if (edge2_edge5) {
							e5_Borderland = true;
						}
						if (edge2_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 2.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex3 != null) {
			if (adjHex3.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex3.GetComponent<BlankHex> ().roadAt6 && roadAt3) || (!adjHex3.GetComponent<BlankHex> ().roadAt6 && !roadAt3)) {
					if (adjHex3.GetComponent<BlankHex> ().GetEdge6_Borderland ()) {
						oneNeighborAdjacentToBorderland = true;
						e3_Borderland = true;
						if (edge3_edge1) {
							e1_Borderland = true;
						}
						if (edge3_edge2) {
							e2_Borderland = true;
						}
						if (edge3_edge4) {
							e4_Borderland = true;
						}
						if (edge3_edge5) {
							e5_Borderland = true;
						}
						if (edge3_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 3.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;
				}
			}
		}
		if (adjHex4 != null) {
			if (adjHex4.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex4.GetComponent<BlankHex> ().roadAt1 && roadAt4) || (!adjHex4.GetComponent<BlankHex> ().roadAt1 && !roadAt4)) {
					if (adjHex4.GetComponent<BlankHex> ().GetEdge1_Borderland ()) {
						oneNeighborAdjacentToBorderland = true;
						e4_Borderland = true;
						if (edge4_edge1) {
							e1_Borderland = true;
						}
						if (edge4_edge2) {
							e2_Borderland = true;
						}
						if (edge4_edge3) {
							e3_Borderland = true;
						}
						if (edge4_edge5) {
							e5_Borderland = true;
						}
						if (edge4_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 4.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;
				}
			}
		}
		if (adjHex5 != null) {
			if (adjHex5.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex5.GetComponent<BlankHex> ().roadAt2 && roadAt5) || (!adjHex5.GetComponent<BlankHex> ().roadAt2 && !roadAt5)) {
					if (adjHex5.GetComponent<BlankHex> ().GetEdge2_Borderland ()) {
						oneNeighborAdjacentToBorderland = true;
						e5_Borderland = true;
						if (edge5_edge1) {
							e1_Borderland = true;
						}
						if (edge5_edge2) {
							e2_Borderland = true;
						}
						if (edge5_edge3) {
							e3_Borderland = true;
						}
						if (edge5_edge4) {
							e4_Borderland = true;
						}
						if (edge5_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 5.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;
				}
			}
		}
		if (adjHex6 != null) {
			if (adjHex6.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex6.GetComponent<BlankHex> ().roadAt3 && roadAt6) || (!adjHex6.GetComponent<BlankHex> ().roadAt3 && !roadAt6)) {
					if (adjHex6.GetComponent<BlankHex> ().GetEdge3_Borderland ()) {
						oneNeighborAdjacentToBorderland = true;
						e6_Borderland = true;
						if (edge6_edge1) {
							e1_Borderland = true;
						}
						if (edge6_edge2) {
							e2_Borderland = true;
						}
						if (edge6_edge3) {
							e3_Borderland = true;
						}
						if (edge6_edge4) {
							e4_Borderland = true;
						}
						if (edge6_edge5) {
							e5_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 6.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;
				}
			}
		}
		if (oneNeighborAdjacentToBorderland == false) {
			Debug.Log ("Illegal placement.  No neighbor has a path connecting to this hex that leads back to the Borderland.");
			gameObject.GetComponent<SpriteRenderer> ().color = redColor;
			return false;//placement is illegal, end function
		}
		return true;
	}



	//check if 6-clearing tile placement is legal based on roads of connected tiles leading back to the Borderland; currently only really matters with the Cliff and Ledge tiles.
	private bool SixClearingTilePlacementCheck(){
		if (adjHex1 != null) {
			if (adjHex1.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex1.GetComponent<BlankHex> ().roadAt4 && roadAt1) || (!adjHex1.GetComponent<BlankHex> ().roadAt4 && !roadAt1)) {
					if (adjHex1.GetComponent<BlankHex> ().GetEdge4_Borderland ()) {//check if adjacent hex connects to Borderland from this hex's connected edge
						e1_Borderland = true;
						if (edge1_edge2) {
							e2_Borderland = true;
						}
						if (edge1_edge3) {
							e3_Borderland = true;
						}
						if (edge1_edge4) {
							e4_Borderland = true;
						}
						if (edge1_edge5) {
							e5_Borderland = true;
						}
						if (edge1_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 1.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex2 != null) {
			if (adjHex2.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex2.GetComponent<BlankHex> ().roadAt5 && roadAt2) || (!adjHex2.GetComponent<BlankHex> ().roadAt5 && !roadAt2)) {
					if (adjHex2.GetComponent<BlankHex> ().GetEdge5_Borderland ()) {
						e2_Borderland = true;
						if (edge2_edge1) {
							e1_Borderland = true;
						}
						if (edge2_edge3) {
							e3_Borderland = true;
						}
						if (edge2_edge4) {
							e4_Borderland = true;
						}
						if (edge2_edge5) {
							e5_Borderland = true;
						}
						if (edge2_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 2.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex3 != null) {
			if (adjHex3.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex3.GetComponent<BlankHex> ().roadAt6 && roadAt3) || (!adjHex3.GetComponent<BlankHex> ().roadAt6 && !roadAt3)) {
					if (adjHex3.GetComponent<BlankHex> ().GetEdge6_Borderland ()) {
						e3_Borderland = true;
						if (edge3_edge1) {
							e1_Borderland = true;
						}
						if (edge3_edge2) {
							e2_Borderland = true;
						}
						if (edge3_edge4) {
							e4_Borderland = true;
						}
						if (edge3_edge5) {
							e5_Borderland = true;
						}
						if (edge3_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 3.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex4 != null) {
			if (adjHex4.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex4.GetComponent<BlankHex> ().roadAt1 && roadAt4) || (!adjHex4.GetComponent<BlankHex> ().roadAt1 && !roadAt4)) {
					if (adjHex4.GetComponent<BlankHex> ().GetEdge1_Borderland ()) {
						e4_Borderland = true;
						if (edge4_edge1) {
							e1_Borderland = true;
						}
						if (edge4_edge2) {
							e2_Borderland = true;
						}
						if (edge4_edge3) {
							e3_Borderland = true;
						}
						if (edge4_edge5) {
							e5_Borderland = true;
						}
						if (edge4_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 4.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex5 != null) {
			if (adjHex5.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex5.GetComponent<BlankHex> ().roadAt2 && roadAt5) || (!adjHex5.GetComponent<BlankHex> ().roadAt2 && !roadAt5)) {
					if (adjHex5.GetComponent<BlankHex> ().GetEdge2_Borderland ()) {
						e5_Borderland = true;
						if (edge5_edge1) {
							e1_Borderland = true;
						}
						if (edge5_edge2) {
							e2_Borderland = true;
						}
						if (edge5_edge3) {
							e3_Borderland = true;
						}
						if (edge5_edge4) {
							e4_Borderland = true;
						}
						if (edge5_edge6) {
							e6_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 5.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}
		if (adjHex6 != null) {
			if (adjHex6.GetComponent<BlankHex> ().HexIsPlaced ()) {
				if ((adjHex6.GetComponent<BlankHex> ().roadAt3 && roadAt6) || (!adjHex6.GetComponent<BlankHex> ().roadAt3 && !roadAt6)) {
					if (adjHex6.GetComponent<BlankHex> ().GetEdge3_Borderland ()) {
						e6_Borderland = true;
						if (edge6_edge1) {
							e1_Borderland = true;
						}
						if (edge6_edge2) {
							e2_Borderland = true;
						}
						if (edge6_edge3) {
							e3_Borderland = true;
						}
						if (edge6_edge4) {
							e4_Borderland = true;
						}
						if (edge6_edge5) {
							e5_Borderland = true;
						}
					}
				} else {
					Debug.Log ("Illegal to place adjacent to neighbor 6.");
					gameObject.GetComponent<SpriteRenderer> ().color = redColor;
					return false;//placement is illegal, end function
				}
			}
		}

		if (roadAt1 && e1_Borderland == false) {
			if (edge1_edge2 && e2_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge1_edge3 && e3_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge1_edge4 && e4_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge1_edge5 && e5_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge1_edge6 && e6_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}

		if (roadAt2 && e2_Borderland == false) {
			if (edge2_edge1 && e1_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge2_edge3 && e3_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge2_edge4 && e4_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge2_edge5 && e5_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge2_edge6 && e6_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}

		if (roadAt3 && e3_Borderland == false) {
			if (edge3_edge1 && e1_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge3_edge2 && e2_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge3_edge4 && e4_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge3_edge5 && e5_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge3_edge6 && e6_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}

		if (roadAt4 && e4_Borderland == false) {
			if (edge4_edge1 && e1_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge4_edge2 && e2_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge4_edge3 && e3_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge4_edge5 && e5_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge4_edge6 && e6_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}

		if (roadAt5 && e5_Borderland == false) {
			if (edge5_edge1 && e1_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge5_edge2 && e2_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge5_edge3 && e3_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge5_edge4 && e4_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge5_edge6 && e6_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}

		if (roadAt6 && e6_Borderland == false) {
			if (edge6_edge1 && e1_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge6_edge2 && e2_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge6_edge3 && e3_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge6_edge4 && e4_Borderland) {
				//do nothing, placement is legal so far
			} else if (edge6_edge5 && e5_Borderland) {
				//do nothing, placement is legal so far
			} else {
				return false;//placement is illegal
			}
		}
		return true;
	}


	//this function is called when a new tile is placed, and the neighbor "hex" needs to have its paths to Borderland updated
	//"edge" represents the edge that connects to the neighbor, who's edge DOES connect to Borderland
	//if the neighbor is adjacent to "hex" edge4 and the "hex" has a path that leads to the borderlands which connects to edge 4, 
	//then the neighbor's edge1 connects to Borderland, thus this "hex" edge4 must also connect to Borderland because it connects to that neighbor's edge
	//EX: if edge == 1, then all the hex's edges that connect to edge 1 also connect to the Borderland, and any neighbor connected to any of those edges should be updated if necessary
	private void UpdatePathsToBorderland(GameObject hex, int edge){

		//update all edges based on the 1 edge that now connects to Borderland
		if (hex.GetComponent<BlankHex> ().e1_Borderland == false && edge == 1) {
			hex.GetComponent<BlankHex> ().e1_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge1 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge1_edge2 && hex.GetComponent<BlankHex> ().e2_Borderland == false) {
				hex.GetComponent<BlankHex> ().e2_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge2 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge1_edge3 && hex.GetComponent<BlankHex> ().e3_Borderland == false) {
				hex.GetComponent<BlankHex> ().e3_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge3 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge1_edge4 && hex.GetComponent<BlankHex> ().e4_Borderland == false) {
				hex.GetComponent<BlankHex> ().e4_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge4 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge1_edge5 && hex.GetComponent<BlankHex> ().e5_Borderland == false) {
				hex.GetComponent<BlankHex> ().e5_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge5 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge1_edge6 && hex.GetComponent<BlankHex> ().e6_Borderland == false) {
				hex.GetComponent<BlankHex> ().e6_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge6 now linked to Borderland.");
			}
		}
		if (hex.GetComponent<BlankHex> ().e2_Borderland == false && edge == 2) {
			hex.GetComponent<BlankHex> ().e2_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge2 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge2_edge1 && hex.GetComponent<BlankHex> ().e1_Borderland == false) {
				hex.GetComponent<BlankHex> ().e1_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge1 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge2_edge3 && hex.GetComponent<BlankHex> ().e3_Borderland == false) {
				hex.GetComponent<BlankHex> ().e3_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge3 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge2_edge4 && hex.GetComponent<BlankHex> ().e4_Borderland == false) {
				hex.GetComponent<BlankHex> ().e4_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge4 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge2_edge5 && hex.GetComponent<BlankHex> ().e5_Borderland == false) {
				hex.GetComponent<BlankHex> ().e5_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge5 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge2_edge6 && hex.GetComponent<BlankHex> ().e6_Borderland == false) {
				hex.GetComponent<BlankHex> ().e6_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge6 now linked to Borderland.");
			}
		}
		if (hex.GetComponent<BlankHex> ().e3_Borderland == false && edge == 3) {
			hex.GetComponent<BlankHex> ().e3_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge3 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge3_edge1 && hex.GetComponent<BlankHex> ().e1_Borderland == false) {
				hex.GetComponent<BlankHex> ().e1_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge1 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge3_edge2 && hex.GetComponent<BlankHex> ().e2_Borderland == false) {
				hex.GetComponent<BlankHex> ().e2_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge2 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge3_edge4 && hex.GetComponent<BlankHex> ().e4_Borderland == false) {
				hex.GetComponent<BlankHex> ().e4_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge4 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge3_edge5 && hex.GetComponent<BlankHex> ().e5_Borderland == false) {
				hex.GetComponent<BlankHex> ().e5_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge5 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge3_edge6 && hex.GetComponent<BlankHex> ().e6_Borderland == false) {
				hex.GetComponent<BlankHex> ().e6_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge6 now linked to Borderland.");
			}
		}
		if (hex.GetComponent<BlankHex> ().e4_Borderland == false && edge == 4) {
			hex.GetComponent<BlankHex> ().e4_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge4 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge4_edge1 && hex.GetComponent<BlankHex> ().e1_Borderland == false) {
				hex.GetComponent<BlankHex> ().e1_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge1 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge4_edge2 && hex.GetComponent<BlankHex> ().e2_Borderland == false) {
				hex.GetComponent<BlankHex> ().e2_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge2 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge4_edge3 && hex.GetComponent<BlankHex> ().e3_Borderland == false) {
				hex.GetComponent<BlankHex> ().e3_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge3 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge4_edge5 && hex.GetComponent<BlankHex> ().e5_Borderland == false) {
				hex.GetComponent<BlankHex> ().e5_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge5 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge4_edge6 && hex.GetComponent<BlankHex> ().e6_Borderland == false) {
				hex.GetComponent<BlankHex> ().e6_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge6 now linked to Borderland.");
			}
		}
		if (hex.GetComponent<BlankHex> ().e5_Borderland == false && edge == 5) {
			hex.GetComponent<BlankHex> ().e5_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge5 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge5_edge1 && hex.GetComponent<BlankHex> ().e1_Borderland == false) {
				hex.GetComponent<BlankHex> ().e1_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge1 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge5_edge2 && hex.GetComponent<BlankHex> ().e2_Borderland == false) {
				hex.GetComponent<BlankHex> ().e2_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge2 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge5_edge3 && hex.GetComponent<BlankHex> ().e3_Borderland == false) {
				hex.GetComponent<BlankHex> ().e3_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge3 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge5_edge4 && hex.GetComponent<BlankHex> ().e4_Borderland == false) {
				hex.GetComponent<BlankHex> ().e4_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge4 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge5_edge6 && hex.GetComponent<BlankHex> ().e6_Borderland == false) {
				hex.GetComponent<BlankHex> ().e6_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge6 now linked to Borderland.");
			}
		}
		if (hex.GetComponent<BlankHex> ().e6_Borderland == false && edge == 6) {
			hex.GetComponent<BlankHex> ().e6_Borderland = true;
			hex.GetComponent<BlankHex> ().visualEdge6Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
			Debug.Log (hex.name + " edge6 now linked to Borderland.");
			if (hex.GetComponent<BlankHex> ().edge6_edge1 && hex.GetComponent<BlankHex> ().e1_Borderland == false) {
				hex.GetComponent<BlankHex> ().e1_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge1Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge1 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge6_edge2 && hex.GetComponent<BlankHex> ().e2_Borderland == false) {
				hex.GetComponent<BlankHex> ().e2_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge2Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge2 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge6_edge3 && hex.GetComponent<BlankHex> ().e3_Borderland == false) {
				hex.GetComponent<BlankHex> ().e3_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge3Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge3 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge6_edge4 && hex.GetComponent<BlankHex> ().e4_Borderland == false) {
				hex.GetComponent<BlankHex> ().e4_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge4Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge4 now linked to Borderland.");
			}
			if (hex.GetComponent<BlankHex> ().edge6_edge5 && hex.GetComponent<BlankHex> ().e5_Borderland == false) {
				hex.GetComponent<BlankHex> ().e5_Borderland = true;
				hex.GetComponent<BlankHex> ().visualEdge5Aid.GetComponent<MeshRenderer> ().material = greenMaterial;
				Debug.Log (hex.name + " edge5 now linked to Borderland.");
			}
		}

		//now that all edges are updated, check neighbors adjacent to edges that connect to Borderland
		if (edge != 1 && hex.GetComponent<BlankHex> ().e1_Borderland &&
		   hex.GetComponent<BlankHex> ().GetNeighbor1 ().GetComponent<BlankHex> ().HexIsPlaced () &&
		   hex.GetComponent<BlankHex> ().GetNeighbor1 ().GetComponent<BlankHex> ().e4_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor1 (), 4);
		}
		if (edge != 2 && hex.GetComponent<BlankHex> ().e2_Borderland &&
			hex.GetComponent<BlankHex> ().GetNeighbor2 ().GetComponent<BlankHex> ().HexIsPlaced () &&
			hex.GetComponent<BlankHex> ().GetNeighbor2 ().GetComponent<BlankHex> ().e5_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor2 (), 5);
		}
		if (edge != 3 && hex.GetComponent<BlankHex> ().e3_Borderland &&
			hex.GetComponent<BlankHex> ().GetNeighbor3 ().GetComponent<BlankHex> ().HexIsPlaced () &&
			hex.GetComponent<BlankHex> ().GetNeighbor3 ().GetComponent<BlankHex> ().e6_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor3 (), 6);
		}
		if (edge != 4 && hex.GetComponent<BlankHex> ().e4_Borderland &&
			hex.GetComponent<BlankHex> ().GetNeighbor4 ().GetComponent<BlankHex> ().HexIsPlaced () &&
			hex.GetComponent<BlankHex> ().GetNeighbor4 ().GetComponent<BlankHex> ().e1_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor4 (), 1);
		}
		if (edge != 5 && hex.GetComponent<BlankHex> ().e5_Borderland &&
			hex.GetComponent<BlankHex> ().GetNeighbor5 ().GetComponent<BlankHex> ().HexIsPlaced () &&
			hex.GetComponent<BlankHex> ().GetNeighbor5 ().GetComponent<BlankHex> ().e2_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor5 (), 2);
		}
		if (edge != 6 && hex.GetComponent<BlankHex> ().e6_Borderland &&
			hex.GetComponent<BlankHex> ().GetNeighbor6 ().GetComponent<BlankHex> ().HexIsPlaced () &&
			hex.GetComponent<BlankHex> ().GetNeighbor6 ().GetComponent<BlankHex> ().e3_Borderland == false) {
			UpdatePathsToBorderland (hex.GetComponent<BlankHex> ().GetNeighbor6 (), 3);
		}
	}

	public void EndOfMapBuilding(){
		if (GameObject.FindGameObjectWithTag ("Canvas").GetComponent<UI_TileDisplay> ().GetDisplayedUITiles ().Count == 0) {
			Destroy (visualEdge1Aid);
			Destroy (visualEdge2Aid);
			Destroy (visualEdge3Aid);
			Destroy (visualEdge4Aid);
			Destroy (visualEdge5Aid);
			Destroy (visualEdge6Aid);
		}
	}

}